configs = {
    'db': {},
    'session': {}
}
